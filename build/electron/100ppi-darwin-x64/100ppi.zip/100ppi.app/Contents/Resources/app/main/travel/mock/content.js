"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const MOCK_CONTENT = `
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#c7d8ff" class="ftab" id="fdata">
    <tbody>
			<tr>
					<td rowspan="2" align="center" bgcolor="#fafdff"><strong>商品</strong></td>
					<td align="center" bgcolor="#e9f1fb"><strong>现货 </strong></td>
					<td colspan="3" align="center" bgcolor="#e9f1fb"><strong>最近合约</strong></td>
					<td colspan="3" align="center" bgcolor="#e9f1fb"><strong>主力合约</strong></td>
			</tr>
			<tr>
					<td align="center" bgcolor="#fafdff">价格</td>
					<td align="center" bgcolor="#fafdff">代码</td>
					<td align="center" bgcolor="#fafdff">价格</td>
					<td align="center" bgcolor="#fafdff">现期差1</td>
					<td align="center" bgcolor="#fafdff">代码</td>
					<td align="center" bgcolor="#fafdff">价格</td>
					<td align="center" bgcolor="#fafdff">现期差2</td>
			</tr>
			
			<tr>
					<td colspan="8"
							style="font:bold 14px; color:#21469f;height:20px;line-height:20px;background-color:#e9f1fb;text-align:center;">
							上海期货交易所
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/792.html" style="color:#21469f;" target="_blank">铜</a></td>
					<td>50520.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>50500&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">20</font></td>
											<td width="50%" align="center"><font color="red">0.04%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1811&nbsp;</td>
					<td>50390&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">130</font></td>
											<td width="50%" align="center"><font color="red">0.26%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/927.html" style="color:#21469f;" target="_blank">螺纹钢</a></td>
					<td>4574.62&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>4569&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">5</font></td>
											<td width="50%" align="center"><font color="red">0.11%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>4054&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">520</font></td>
											<td width="50%" align="center"><font color="red">11.37%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/826.html" style="color:#21469f;" target="_blank">锌</a></td>
					<td>23000.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>22390&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">610</font></td>
											<td width="50%" align="center"><font color="red">2.65%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1811&nbsp;</td>
					<td>21595&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">1405</font></td>
											<td width="50%" align="center"><font color="red">6.11%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/827.html" style="color:#21469f;" target="_blank">铝</a></td>
					<td>14440.00&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>14490&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-50</font></td>
											<td width="50%" align="center"><font color="green">-0.35%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1811&nbsp;</td>
					<td>14490&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-50</font></td>
											<td width="50%" align="center"><font color="green">-0.35%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/551.html" style="color:#21469f;" target="_blank">黄金</a></td>
					<td>266.48&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>266.25&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">0.23</font></td>
											<td width="50%" align="center"><font color="red">0.09%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1812&nbsp;</td>
					<td>267.6&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-1.12</font></td>
											<td width="50%" align="center"><font color="green">-0.42%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/586.html" style="color:#21469f;" target="_blank">天然橡胶</a></td>
					<td>10888.89&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>10675&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">213</font></td>
											<td width="50%" align="center"><font color="red">1.96%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>12400&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-1511</font></td>
											<td width="50%" align="center"><font color="green">-13.88%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/825.html" style="color:#21469f;" target="_blank">铅</a></td>
					<td>18450.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>18230&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">220</font></td>
											<td width="50%" align="center"><font color="red">1.19%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1811&nbsp;</td>
					<td>17925&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">525</font></td>
											<td width="50%" align="center"><font color="red">2.85%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/544.html" style="color:#21469f;" target="_blank">白银</a></td>
					<td>3495.67&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>3523&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-27</font></td>
											<td width="50%" align="center"><font color="green">-0.77%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1812&nbsp;</td>
					<td>3506&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-10</font></td>
											<td width="50%" align="center"><font color="green">-0.29%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1022.html" style="color:#21469f;" target="_blank">石油沥青</a></td>
					<td>3967.53&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>3484&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">483</font></td>
											<td width="50%" align="center"><font color="red">12.17%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1812&nbsp;</td>
					<td>3686&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">281</font></td>
											<td width="50%" align="center"><font color="red">7.08%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/195.html" style="color:#21469f;" target="_blank">热轧卷板</a></td>
					<td>4295.83&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>4269&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">26</font></td>
											<td width="50%" align="center"><font color="red">0.61%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>3934&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">361</font></td>
											<td width="50%" align="center"><font color="red">8.40%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1182.html" style="color:#21469f;" target="_blank">镍</a></td>
					<td>108800.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>104270&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">4530</font></td>
											<td width="50%" align="center"><font color="red">4.16%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1811&nbsp;</td>
					<td>105050&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">3750</font></td>
											<td width="50%" align="center"><font color="red">3.45%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1181.html" style="color:#21469f;" target="_blank">锡</a></td>
					<td>146000.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>147830&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-1830</font></td>
											<td width="50%" align="center"><font color="green">-1.25%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>147270&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-1270</font></td>
											<td width="50%" align="center"><font color="green">-0.87%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
	
			<tr>
					<td colspan="8"
							style="font:bold 14px; color:#21469f;height:20px;line-height:20px;background-color:#e9f1fb;text-align:center;">
							郑州商品交易所
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/356.html" style="color:#21469f;" target="_blank">PTA</a></td>
					<td>8017.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>7814&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">203</font></td>
											<td width="50%" align="center"><font color="red">2.53%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>7164&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">853</font></td>
											<td width="50%" align="center"><font color="red">10.64%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/564.html" style="color:#21469f;" target="_blank">白糖</a></td>
					<td>5472.00&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>4701&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">771</font></td>
											<td width="50%" align="center"><font color="red">14.09%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>5006&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">466</font></td>
											<td width="50%" align="center"><font color="red">8.52%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/344.html" style="color:#21469f;" target="_blank">棉花</a></td>
					<td>16303.71&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>15345&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">958</font></td>
											<td width="50%" align="center"><font color="red">5.88%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>15770&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">533</font></td>
											<td width="50%" align="center"><font color="red">3.27%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/349.html" style="color:#21469f;" target="_blank">普麦</a></td>
					<td>2462.00&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>2324&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">138</font></td>
											<td width="50%" align="center"><font color="red">5.61%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>2376&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">86</font></td>
											<td width="50%" align="center"><font color="red">3.49%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/810.html" style="color:#21469f;" target="_blank">菜籽油OI</a></td>
					<td>6601.67&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>6535&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">66</font></td>
											<td width="50%" align="center"><font color="red">1.00%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>6671&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-69</font></td>
											<td width="50%" align="center"><font color="green">-1.05%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/959.html" style="color:#21469f;" target="_blank">玻璃</a></td>
					<td>19.73&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>1440&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">138</font></td>
											<td width="50%" align="center"><font color="red">8.74%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>1366&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">212</font></td>
											<td width="50%" align="center"><font color="red">13.43%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1014.html" style="color:#21469f;" target="_blank">菜籽粕</a></td>
					<td>2503.33&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>2548&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-44</font></td>
											<td width="50%" align="center"><font color="green">-1.76%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>2464&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">39</font></td>
											<td width="50%" align="center"><font color="red">1.56%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1087.html" style="color:#21469f;" target="_blank">油菜籽</a></td>
					<td>5100.00&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>5269&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-169</font></td>
											<td width="50%" align="center"><font color="green">-3.31%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1908&nbsp;</td>
					<td>5437&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-337</font></td>
											<td width="50%" align="center"><font color="green">-6.61%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1154.html" style="color:#21469f;" target="_blank">硅铁</a></td>
					<td>6556.25&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>6806&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-249</font></td>
											<td width="50%" align="center"><font color="green">-3.80%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>6628&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-71</font></td>
											<td width="50%" align="center"><font color="green">-1.08%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1155.html" style="color:#21469f;" target="_blank">锰硅</a></td>
					<td>8771.43&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>8872&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-100</font></td>
											<td width="50%" align="center"><font color="green">-1.14%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>8482&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">289</font></td>
											<td width="50%" align="center"><font color="red">3.29%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/817.html" style="color:#21469f;" target="_blank">甲醇MA</a></td>
					<td>3315.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>3395&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-80</font></td>
											<td width="50%" align="center"><font color="green">-2.41%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>3255&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">60</font></td>
											<td width="50%" align="center"><font color="red">1.81%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/369.html" style="color:#21469f;" target="_blank">动力煤ZC</a></td>
					<td>638.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>650&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-12</font></td>
											<td width="50%" align="center"><font color="green">-1.88%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>631&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">7</font></td>
											<td width="50%" align="center"><font color="red">1.10%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1258.html" style="color:#21469f;" target="_blank">棉纱</a></td>
					<td>25075.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>25030&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">45</font></td>
											<td width="50%" align="center"><font color="red">0.18%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1810&nbsp;</td>
					<td>25030&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">45</font></td>
											<td width="50%" align="center"><font color="red">0.18%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
	
			<tr>
					<td colspan="8"
							style="font:bold 14px; color:#21469f;height:20px;line-height:20px;background-color:#e9f1fb;text-align:center;">
							大连商品交易所
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1084.html" style="color:#21469f;" target="_blank">棕榈油</a></td>
					<td>4722.50&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>4874&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-151</font></td>
											<td width="50%" align="center"><font color="green">-3.20%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>4718&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">4.50</font></td>
											<td width="50%" align="center"><font color="red">0.10%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/107.html" style="color:#21469f;" target="_blank">聚氯乙烯</a></td>
					<td>6823.00&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>6870&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-47</font></td>
											<td width="50%" align="center"><font color="green">-0.69%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>6650&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">173</font></td>
											<td width="50%" align="center"><font color="red">2.54%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/435.html" style="color:#21469f;" target="_blank">聚乙烯</a></td>
					<td>9722.22&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>9270&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">452</font></td>
											<td width="50%" align="center"><font color="red">4.65%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>9460&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">262</font></td>
											<td width="50%" align="center"><font color="red">2.69%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1080.html" style="color:#21469f;" target="_blank">豆一</a></td>
					<td>3640.00&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>3666&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-26</font></td>
											<td width="50%" align="center"><font color="green">-0.71%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>3717&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-77</font></td>
											<td width="50%" align="center"><font color="green">-2.12%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/312.html" style="color:#21469f;" target="_blank">豆粕</a></td>
					<td>3413.33&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>3468&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-54</font></td>
											<td width="50%" align="center"><font color="green">-1.58%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>3298&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">115</font></td>
											<td width="50%" align="center"><font color="red">3.37%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/403.html" style="color:#21469f;" target="_blank">豆油</a></td>
					<td>5723.75&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>5902&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-178</font></td>
											<td width="50%" align="center"><font color="green">-3.11%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>5852&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-128</font></td>
											<td width="50%" align="center"><font color="green">-2.24%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/274.html" style="color:#21469f;" target="_blank">玉米</a></td>
					<td>1786.14&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>1829&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-42</font></td>
											<td width="50%" align="center"><font color="green">-2.35%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>1854&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="green">-67</font></td>
											<td width="50%" align="center"><font color="green">-3.75%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/617.html" style="color:#21469f;" target="_blank">焦炭</a></td>
					<td>2403.33&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>2339.5&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">63</font></td>
											<td width="50%" align="center"><font color="red">2.62%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>2276&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">127</font></td>
											<td width="50%" align="center"><font color="red">5.28%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1121.html" style="color:#21469f;" target="_blank">焦煤</a></td>
					<td>1564.17&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>1303&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">261</font></td>
											<td width="50%" align="center"><font color="red">16.69%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>1272&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">292</font></td>
											<td width="50%" align="center"><font color="red">18.67%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/961.html" style="color:#21469f;" target="_blank">铁矿石</a></td>
					<td>526.22&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>517.5&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">8</font></td>
											<td width="50%" align="center"><font color="red">1.52%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>500.5&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">25</font></td>
											<td width="50%" align="center"><font color="red">4.75%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1049.html" style="color:#21469f;" target="_blank">鸡蛋</a></td>
					<td>8.93&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>3852&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">613</font></td>
											<td width="50%" align="center"><font color="red">13.73%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>3915&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">550</font></td>
											<td width="50%" align="center"><font color="red">12.32%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/718.html" style="color:#21469f;" target="_blank">聚丙烯</a></td>
					<td>10466.67&nbsp;</td>
					<td>1810&nbsp;</td>
					<td>10422&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">44</font></td>
											<td width="50%" align="center"><font color="red">0.42%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>9952&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">514</font></td>
											<td width="50%" align="center"><font color="red">4.91%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
			<tr align="center" bgcolor="#fafdff">
					<td><a href="http://www.100ppi.com/sf/1209.html" style="color:#21469f;" target="_blank">玉米淀粉</a></td>
					<td>2461.82&nbsp;</td>
					<td>1811&nbsp;</td>
					<td>2286&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">175</font></td>
											<td width="50%" align="center"><font color="red">7.11%</font></td>
									</tr>
									</tbody>
							</table>
	
					</td>
					<td>1901&nbsp;</td>
					<td>2314&nbsp;</td>
					<td>
							<table width="100%">
									<tbody>
									<tr>
											<td width="50%" align="center"><font color="red">147</font></td>
											<td width="50%" align="center"><font color="red">5.97%</font></td>
									</tr>
									</tbody>
							</table>
					</td>
			</tr>
    </tbody>
</table>
`;
exports.default = MOCK_CONTENT;
//# sourceMappingURL=content.js.map